package com.hexaware.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class MessageService {

    private IService messageService1;
    private IService messageService2;

    public MessageService(@Qualifier("smsService") IService messageService1, @Qualifier("emailService") IService messageService2) {
        this.messageService1 = messageService1;
        this.messageService2 = messageService2;
    }


    public void sendmessage(String msg, int type) {
        if (type == 1)
            this.messageService1.message(msg); // sms
        else if (type == 2)
            this.messageService2.message(msg); // email
        else
            System.out.print("Wrong msg");
    }
}

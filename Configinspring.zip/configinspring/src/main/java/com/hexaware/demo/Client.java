package com.hexaware.demo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Client {
 public static void main(String[] args)
 {  // container creation
	 ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);

	Car obj = applicationContext.getBean(Car.class);
	//getBean -> method of applicationContext
	obj.move();
 }
}

// appconfig manages beans files
// applicationContext is an interface
// AnnotationConfigurationApplicationContext-> it looks after which configuration to use
//  -> the configuration is stored inside appconfig -> java based configuration 
package com.hexaware.demo;


public interface Vehicle {
	public void move();
	//public void startJourney();
}
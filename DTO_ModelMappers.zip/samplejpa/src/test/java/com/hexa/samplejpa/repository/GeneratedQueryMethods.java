package com.hexa.samplejpa.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexa.samplejpa.entity.Product;

@SpringBootTest
public class GeneratedQueryMethods {
	public final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	@Autowired
	ProductRepository prodRepo;

	@Test
	void findDistinctByNameTest() {
		Product resultObject = prodRepo.findDistinctByName("Mouse");
		LOGGER.log(Level.INFO, "record" + resultObject);
    
	}
	@Test
	void findByNameContainingTest() {
		List <Product> resultObject = prodRepo.findByNameContaining("Mouse");
		LOGGER.log(Level.INFO, "records found containing text mouse");
        resultObject.forEach((p)->{System.out.println(p);});
	}
    @Test
    void findByPriceBetweenTest()
    {
    	BigDecimal startPrice = new BigDecimal(3000.00);
    	BigDecimal endPrice  = new BigDecimal(40000.00);
    	List<Product> foundList = prodRepo.findByPriceBetween(startPrice, endPrice);
    	LOGGER.log(Level.INFO, "records found containing text mouse" + foundList);
    }
	
  // HomeWork  
  //List<Product> findByDateCreatedBetween(LocalDateTime startDate, LocalDateTime endDate)
  //List<Product> findByPriceBetween(BigDecimal  startPrice,BigDecimal endPrice )
  //List<Product> findByNameLike(String name)
  //List<Product> findByNameIn(List<String> names)
  //FindByFirst2Name(String name) //has context menu
    
    
    
    
    
    
    
    
    
}

package com.hexa.samplejpa.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class MethodGenerationTest {
@Autowired
	ProductRepository profRepo;
@Test
public void test()
{
	System.out.println(profRepo.searchProducts("Mouse"));
}
}

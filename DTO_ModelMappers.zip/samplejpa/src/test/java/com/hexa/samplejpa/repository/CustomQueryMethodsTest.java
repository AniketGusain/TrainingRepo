package com.hexa.samplejpa.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CustomQueryMethodsTest {
    @Autowired
	private ProductRepository profRepo;
    @Test
    void searchProductsTest()
    {
    	profRepo.searchProducts("Mouse");
    }
    @Test
    void searchProductsTest1()
    {
    	profRepo.searchProduct1("Keyboard");
    }
}

package com.hexa.samplejpa.mapper;

import com.hexa.samplejpa.dto.ProductDTO;
import com.hexa.samplejpa.entity.Product;

public class ProductMapper {
public static ProductDTO mapToProductDTO(Product p)
{
	ProductDTO productDTO = new ProductDTO(p);
	return productDTO;
}

public static Product mapToProduct(ProductDTO p)
{
    Product product = new Product(p);
	return product;
    
}
}

package com.hexa.samplejpa.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.hexa.samplejpa.entity.Product;

public class ProductDTO {
	private Long id;
	private String stockKeepingUnit;
	private String name;
	private BigDecimal price;
	private String description;
	private Boolean active;
	private String imageURL;
	private LocalDateTime dateCreated;
	private LocalDateTime dateUpdated;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getStockKeepingUnit() {
		return stockKeepingUnit;
	}
	public void setStockKeepingUnit(String stockKeepingUnit) {
		this.stockKeepingUnit = stockKeepingUnit;
	}
	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", stockKeepingUnit=" + stockKeepingUnit + ", name=" + name + ", price=" + price
				+ ", description=" + description + ", active=" + active + ", imageURL=" + imageURL + ", dateCreated="
				+ dateCreated + ", dateUpdated=" + dateUpdated + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Boolean getActive() {
		return active;
	}
	public void setActive(Boolean active) {
		this.active = active;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public LocalDateTime getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(LocalDateTime dateCreated) {
		this.dateCreated = dateCreated;
	}
	public LocalDateTime getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(LocalDateTime dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(Long id, String stockKeepingUnit, String name, BigDecimal price, String description,
			Boolean active, String imageURL, LocalDateTime dateCreated, LocalDateTime dateUpdated) {
		super();
		this.id = id;
		this.stockKeepingUnit = stockKeepingUnit;
		this.name = name;
		this.price = price;
		this.description = description;
		this.active = active;
		this.imageURL = imageURL;
		this.dateCreated = dateCreated;
		this.dateUpdated = dateUpdated;
	}
	public ProductDTO(ProductDTO obj) {
	   	this.id = obj.getId();
		this.stockKeepingUnit = obj.stockKeepingUnit;
		this.name = obj.name;
		this.price = obj.price;
		this.description = obj.description;
		this.active = obj.active;
		this.imageURL = obj.imageURL;
		this.dateCreated = obj.dateCreated;
		this.dateUpdated = obj.dateUpdated;
	}
	public ProductDTO(Product savedProduct) {
		// TODO Auto-generated constructor stub
	}
	
	
	
}

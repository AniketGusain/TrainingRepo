package com.hexa.samplejpa.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexa.samplejpa.dto.ProductDTO;
import com.hexa.samplejpa.entity.Product;
import com.hexa.samplejpa.mapper.ProductMapper;
import com.hexa.samplejpa.repository.ProductRepository;
import com.hexa.samplejpa.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	private ProductRepository productRepository;

	@Autowired
	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}

	// This empty constructor might be useful for certain dependency injection
	// frameworks
	public ProductServiceImpl() {
		super();
	}

	@Override
    public List<Product> searchProducts(String query) {
        // TODO Auto-generated method stub
        List<Product> productList = productRepository.searchProducts(query);
        return productList;
    }
	@Override
    public ProductDTO creatProduct(ProductDTO p) {
        // Convert ProductDTO to Product using ProductMapper
        Product productJPAObject = ProductMapper.mapToProduct(p);

        // Save the Product object to the database
        Product savedProduct = productRepository.save(productJPAObject);

        // Convert the saved Product back to ProductDTO using ProductMapper
        ProductDTO savedProductDTO = ProductMapper.mapToProductDTO(savedProduct);

        return savedProductDTO;
    }
}

/*
 * @Override public ProductDTO creatProduct(ProductDTO p) {
 * 
 * //Product productJPAObject = new Product(p); Product productJPAObject =
 * ProductMapper.mapToProduct(p); // TODO Auto-generated method stub //
 * ConvertDTO to JPA Entity // this object hold the key, values for generated
 * fields creation, usage // timestamps
 * 
 * // Product(p.getId(),p.getStockKeepingUnit(),p.getName(),p.getPrice(),p.
 * getDescription(),p.getActive(),p.getImageURL(),p.getDateUpdated(),p.
 * getDateCreated());
 * 
 * Product savedProduct = productRepository.save(productJPAObject); //ProductDTO
 * savedProductDTO = new ProductDTO(savedProduct); ProductDTO savedProductDTO =
 * ProductMapper.mapToProductDTO(savedProduct);
 * 
 * 
 * ProductDTO savedProductDTO = new ProductDTO(savedProduct.getId(),
 * savedProduct.getStockKeepingUnit(), savedProduct.getName(),
 * savedProduct.getPrice(), savedProduct.getDescription(),
 * savedProduct.getActive(), savedProduct.getImageURL(),
 * savedProduct.getDateUpdated(), savedProduct.getDateCreated());
 * 
 * return savedProductDTO;
 * 
 * // convert Entity to dto
 * 
 * }
 * 
 * }
 */
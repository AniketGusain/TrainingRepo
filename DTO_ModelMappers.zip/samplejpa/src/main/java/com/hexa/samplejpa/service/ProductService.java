package com.hexa.samplejpa.service;

import java.util.List;

import com.hexa.samplejpa.dto.ProductDTO;
import com.hexa.samplejpa.entity.Product;

public interface ProductService {
	List<Product> searchProducts(String query);
	public ProductDTO creatProduct(ProductDTO p);
}

package com.hexaware.demo;

public class Address {
    public void print() {
        System.out.println("Printing address...");
    }
}


package com.hexaware.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BeanAnnotationDemo {
    public static void main(String args[]) {
        ApplicationContext appcontext = new AnnotationConfigApplicationContext(AppConfig.class);
        Student student = (Student) appcontext.getBean(Student.class);
        student.print();
        
        String[] beanNames = appcontext.getBeanDefinitionNames();
        for(String obj : beanNames) {
            System.out.println(obj);
        }
    }
}


package com.hexaware.demo;

public class Student {
    private Address address;

    public Student(Address address) {
        super();
        this.address = address;
    }

    public void print() {
        this.address.print();
        System.out.println("Print from student");
    }
}

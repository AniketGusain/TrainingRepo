package com.hexa.samplejpa.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.hexa.samplejpa.entity.Product;

@SpringBootTest
public class JPAQueriesTest {
	public final static Logger LOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	@Autowired
	ProductRepository prodRepo;

	@Disabled
	@Test

	void saveMethodTest() { // 1. This one we are going to save
		Product p = new Product((long) 300, "available", "laptop", "laptop essentials", true, "lenovoi5.png",
				LocalDateTime.now(), LocalDateTime.now());
		Product savedProduct = prodRepo.save(p);
		// 2. This one is the saved one
		LOGGER.log(Level.INFO, " saved product in db using JPA " + savedProduct);

	}

	@Disabled
	@Test
	void saveMethodUpdateTest() {
		Long id = 66L;// hardcoding
		// Long id = 8L;// hardcoding -> first we have to run this
		Optional<Product> existingProductOptional = prodRepo.findById(id);

		if (existingProductOptional.isPresent()) {
			Product obj = existingProductOptional.get();
			LOGGER.log(Level.INFO, " existing product in db using JPA save()" + obj);
			// update the object
			obj.setName("HP vision");
			obj.setDescription("Laptop essentials updated");
			Product updatedProduct = prodRepo.save(obj);
			LOGGER.log(Level.INFO, " saved product in db using JPA save()" + updatedProduct);
		} else {
			LOGGER.log(Level.INFO, "Object is not present");
		}
	}

	
	@Test
	public void saveAll() {
		Product p1 = new Product((long) 300, "available", "laptop",new BigDecimal(35000.00), "laptop essentials", true, "lenovoi5.png",
				LocalDateTime.now(), LocalDateTime.now());
		Product p2 = new Product((long) 300, "available", "keyboard",new BigDecimal(230.00), "laptop essentials keyboard", true, "keyboard9.png",
				LocalDateTime.now(), LocalDateTime.now());

		Product p3 = new Product((long) 300, "available", "monitor",new BigDecimal(5500.00), "laptop essentials monitor", true,
				"lgmonitori5.png", LocalDateTime.now(), LocalDateTime.now());
		Product p4 = new Product((long) 300, "available", "monitor24",new BigDecimal(6500.00), "laptop essentials monitor samsung", true, "samsungmonitor5.png",
				LocalDateTime.now(), LocalDateTime.now());
		Product p5 = new Product((long) 300, "available", "laptop",new BigDecimal(5000.00), "additional resource ", true, "keyboard9.png",
				LocalDateTime.now(), LocalDateTime.now());

		Product p6 = new Product((long) 300, "available", "router",new BigDecimal(10000.00), "laptop essentials monitor", true,
				"lgmonitori5.png", LocalDateTime.now(), LocalDateTime.now());
	
		
		
		
		
		List<Product> savedProductList = prodRepo.saveAll(List.of(p1, p2, p3,p4,p5,p6));
		LOGGER.log(Level.INFO, "Save records in db" + savedProductList);
	}

	@Disabled
	@Test
	void findAllMethodTest() {
		List<Product> productList = prodRepo.findAll();
		LOGGER.log(Level.INFO, "Found records in db:.. ");
		productList.forEach((p) -> {
			LOGGER.log(Level.INFO, "Records: " + p);
		});
	}

	@Disabled
	@Test
	void deleteByIdMethodTest() {
		Long id = 10L;
		prodRepo.deleteById(id);
		Optional<Product> opt = prodRepo.findById(10L);
		if (opt.isEmpty()) {
			LOGGER.log(Level.INFO, "Record deleted");
		}
	}
	@Disabled
	@Test
	void deleteMethodTest() {
		Long id = 11L;
		Optional<Product> opt = prodRepo.findById(id);
		Product p = opt.get();
		prodRepo.delete(p);
		opt = prodRepo.findById(11L);
		// opt = prodRepo.findById(id);
		if (opt.isEmpty()) {
			LOGGER.log(Level.INFO, "Record deleted");
		}
	}

	@Disabled
	@Test
	void deleteAllMethod() {
		prodRepo.deleteAll();
	}
	@Disabled
	@Test
	void deleteAllWithSelectedTest() {
		Optional<Product> opt1 = prodRepo.findById(4L);
		                      //ID number that you want to delete
		Product p1 = opt1.get();
		Optional<Product> opt2 = prodRepo.findById(6L);
		                      //ID number that you want to delete
		Product p2 = opt2.get();
		prodRepo.deleteAll(List.of(p1, p2));
		if (prodRepo.findById(4L).isEmpty() && prodRepo.findById(6L).isEmpty()) {
			LOGGER.log(Level.INFO, "Record deleted");
		}
	}
	@Disabled
    @Test
    void existByIdMethodTest()
    {
    	boolean existStatus = prodRepo.existsById((long) 2);
    	       LOGGER.log(Level.INFO, "Record exist status "+ existStatus);
		    }
	@Disabled
    @Test
    void countMethodTest()
    {
    	Long count = prodRepo.count();
    	       LOGGER.log(Level.INFO, "Number of records: "+ count);
		    }
	
}

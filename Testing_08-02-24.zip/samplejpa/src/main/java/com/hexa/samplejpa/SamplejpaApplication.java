package com.hexa.samplejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamplejpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SamplejpaApplication.class, args);
	}

}

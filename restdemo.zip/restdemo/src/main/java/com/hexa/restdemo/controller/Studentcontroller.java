package com.hexa.restdemo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexa.restdemo.bean.Student;

@RestController
public class Studentcontroller {
	
	// returns a single object
	@GetMapping("/getStudent")
	public Student getStudent() {
		return new Student(100, "Riju", "Antony");
	}

	// returns a list of students
	@GetMapping("/getStudentList")
	public List<Student> getStudentList() {
		List<Student> myList = new ArrayList<>();
		myList.add(new Student(101, "Rahul", "KR"));
		myList.add(new Student(102, "Sowmya", "T"));
		myList.add(new Student(103, "Laja", "S"));

		return myList;
	}

	// path variable getting details of student with id
	//URL-  localhost:8085/getStudentbyId/102
	@GetMapping("/getStudentbyId/{id}")
	public Student getStudentById(@PathVariable int id) {
		Student result = null;
		List<Student> myList = new ArrayList<>();
		myList.add(new Student(101, "Rahul", "KR"));
		myList.add(new Student(102, "Sowmya", "T"));
		myList.add(new Student(103, "Laja", "S"));

		for (Student obj : myList) {
			if (obj.getId() == id) {
				result = obj;
				break;
			}
		}
		return result;
	}

	// @RequestParam getting details of student with id
	//URL- localhost:8085/getStudentByIdReqParam?id=102
	@GetMapping("/getStudentByIdReqParam")
	public Student getStudentByIdReqParam(@RequestParam("id") int id) {
		Student result = null;
		List<Student> myList = new ArrayList<>();
		myList.add(new Student(101, "Rahul", "KR"));
		myList.add(new Student(102, "Sowmya", "T"));
		myList.add(new Student(103, "Laja", "S"));

		for (Student obj : myList) {
			if (obj.getId() == id) {
				result = obj;
				break;
			}		}
		return result;	}

	// @GetMapping("/getStudentusibfsuppledargs/{studentId}/{firstName}/{lastName}")
	// URL- localhost:8085/getStudentusibfsuppledargs/102/Rahul/T
	
	// public Student getStudent(@PathVariable int studentId, @PathVariable String
	// firstName, @PathVariable String lastName) {
	// return new Student(studentId, firstName, lastName); }

	
	
	
	// returns a single object by passing values from from reqparams //
	// URL- localhost:8085/getStudentusibfsuppledargs?Id=102&fname=Rahul&lname=T
	@GetMapping("/getStudentusibfsuppledargs")
	public Student getStudent(@RequestParam(name = "Id", defaultValue = "100") int studentId,
			@RequestParam(name = "fname") String firstName, @RequestParam(name = "lname") String lastName) {
		return new Student(studentId, firstName, lastName);
	}
	
	// returns a single object created by passing values from reqparams

	//URL- localhost:8085//getStudentusingsuppliedargsreqparamas?id=107&fname=Hema&lname=V&opt=hhg

	@GetMapping("/getStudentusingsuppliedargsreqparamas")

	public Student getStudentobj(@RequestParam(name = "id", defaultValue = "100") int studentId,
			@RequestParam(name = "fname") String firstName,

			@RequestParam(name = "lname") String lastName, @RequestParam(required = false) String opt) {

		return (new Student(studentId, firstName, lastName));

	}
}
